'use client'

import { useState } from 'react'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { useAuth } from '@/contexts/AuthContext'

export default function ForgotPassword() {
  const { resetPassword } = useAuth()
  const [email, setEmail] = useState('')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email) {
      setError('Please enter your email')
      return
    }

    try {
      setError('')
      setMessage('')
      setLoading(true)
      await resetPassword(email)
      setMessage('Check your inbox for password reset instructions')
    } catch (error) {
      setError('Failed to reset password')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="flex items-center mb-8">
        <Link href="/login" className="p-2">
          <ArrowLeft className="w-6 h-6" />
        </Link>
      </div>

      <h1 className="text-3xl font-medium mb-6">Reset Password</h1>

      <p className="text-gray-600 mb-8">
        Enter your email address and we'll send you instructions to reset your password.
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-[#00A651] mb-1">Email address</label>
          <input
            type="email"
            placeholder="Enter your email address"
            className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        {error && (
          <p className="text-red-500 text-sm text-center">{error}</p>
        )}

        {message && (
          <p className="text-green-500 text-sm text-center">{message}</p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full p-4 rounded-xl bg-[#00A651] text-white font-medium hover:bg-[#008c44] transition-colors disabled:opacity-50"
        >
          {loading ? 'Sending...' : 'Send Reset Instructions'}
        </button>

        <p className="text-center">
          <Link href="/login" className="text-[#00A651] hover:underline">
            Back to Login
          </Link>
        </p>
      </form>
    </div>
  )
}

