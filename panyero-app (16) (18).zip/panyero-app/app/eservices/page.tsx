'use client'

import { useState } from 'react'
import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'
import EServicesContent from '../../components/EServicesContent'
import { Search } from 'lucide-react'

export default function EServices() {
  const [searchTerm, setSearchTerm] = useState('')

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] pb-24">
      <Header userLevel={5} />
      <div className="px-4 space-y-6">
        <h1 className="text-2xl font-bold text-[#1a237e]">E-Services</h1>
        <div className="relative">
          <input
            type="text"
            placeholder="Search services..."
            className="w-full p-2 pl-10 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#1a237e]"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        <EServicesContent />
      </div>
      <NavigationBar />
    </div>
  )
}

