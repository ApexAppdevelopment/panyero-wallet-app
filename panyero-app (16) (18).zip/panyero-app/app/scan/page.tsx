import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'
import dynamic from 'next/dynamic'
const QRScanner = dynamic(() => import('../../components/QRScanner'), { ssr: false })

export default function Scan() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4 pb-24">
      <Header userLevel={5} />
      <QRScanner />
      <NavigationBar />
    </div>
  )
}

