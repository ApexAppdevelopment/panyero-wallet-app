import CashIn from '../../components/CashIn'

export default function CashInPage() {
  return <CashIn />
}

