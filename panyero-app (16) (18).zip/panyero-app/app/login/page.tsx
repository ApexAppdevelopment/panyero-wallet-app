'use client'

import { useState } from 'react'
import { ArrowLeft, Eye, EyeOff } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import Image from 'next/image'

export default function Login() {
  const router = useRouter()
  const { signIn } = useAuth()
  const [formData, setFormData] = useState({
    phoneNumber: '',
    password: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.phoneNumber || !formData.password) {
      setError('Please fill in all fields')
      return
    }

    try {
      setError('')
      setLoading(true)
      await signIn(formData.phoneNumber, formData.password)
      router.push('/')
    } catch (error) {
      setError('Failed to sign in')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="flex items-center mb-8">
        <Link href="/" className="p-2">
          <ArrowLeft className="w-6 h-6" />
        </Link>
      </div>

      <div className="flex justify-center mb-12">
        <Image
          src="https://panyero.website/wallet-app/assets/logo-light.png"
          alt="Panyero Logo"
          width={300}
          height={60}
          className="h-16 w-auto"
        />
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex gap-2">
          <div className="w-16">
            <input
              type="text"
              value="+63"
              disabled
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 text-center text-gray-600"
            />
          </div>
          <div className="flex-1">
            <input
              type="tel"
              placeholder="9056741316"
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
              value={formData.phoneNumber}
              onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-[#00A651] mb-1">Password</label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Enter password"
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2"
            >
              {showPassword ? (
                <EyeOff className="w-5 h-5 text-gray-400" />
              ) : (
                <Eye className="w-5 h-5 text-gray-400" />
              )}
            </button>
          </div>
        </div>

        <Link
          href="/forgot-password"
          className="block text-[#00A651] text-center hover:underline"
        >
          Forgot your password?
        </Link>

        {error && (
          <p className="text-red-500 text-sm text-center">{error}</p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full p-4 rounded-xl bg-[#92E3A9] text-white font-medium hover:bg-[#7fcf94] transition-colors disabled:opacity-50"
        >
          {loading ? 'Signing in...' : 'Log in'}
        </button>
      </form>
    </div>
  )
}

