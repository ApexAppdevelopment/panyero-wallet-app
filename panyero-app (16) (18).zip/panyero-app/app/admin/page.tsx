'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { db } from '@/firebase'
import { collection, getDocs, doc, setDoc, deleteDoc } from 'firebase/firestore'

interface Service {
  id: string
  name: string
  url: string
}

export default function AdminDashboard() {
  const [services, setServices] = useState<Service[]>([])
  const [newService, setNewService] = useState({ name: '', url: '' })
  const [editingService, setEditingService] = useState<Service | null>(null)

  useEffect(() => {
    fetchServices()
  }, [])

  const fetchServices = async () => {
    const servicesCollection = collection(db, 'services')
    const serviceSnapshot = await getDocs(servicesCollection)
    const serviceList = serviceSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Service))
    setServices(serviceList)
  }

  const handleAddService = async (e: React.FormEvent) => {
    e.preventDefault()
    if (newService.name && newService.url) {
      const serviceRef = doc(collection(db, 'services'))
      await setDoc(serviceRef, newService)
      setNewService({ name: '', url: '' })
      fetchServices()
    }
  }

  const handleEditService = async (e: React.FormEvent) => {
    e.preventDefault()
    if (editingService) {
      const serviceRef = doc(db, 'services', editingService.id)
      await setDoc(serviceRef, { name: editingService.name, url: editingService.url }, { merge: true })
      setEditingService(null)
      fetchServices()
    }
  }

  const handleDeleteService = async (id: string) => {
    await deleteDoc(doc(db, 'services', id))
    fetchServices()
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] p-4">
      <div className="flex items-center mb-8">
        <Link href="/profile" className="p-2">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-bold ml-2">Admin Dashboard</h1>
      </div>

      <div className="bg-white rounded-xl p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Add New Service</h2>
        <form onSubmit={handleAddService} className="space-y-4">
          <input
            type="text"
            placeholder="Service Name"
            value={newService.name}
            onChange={(e) => setNewService({ ...newService, name: e.target.value })}
            className="w-full p-2 border rounded"
          />
          <input
            type="url"
            placeholder="Service URL"
            value={newService.url}
            onChange={(e) => setNewService({ ...newService, url: e.target.value })}
            className="w-full p-2 border rounded"
          />
          <button type="submit" className="w-full p-2 bg-[#00A651] text-white rounded">Add Service</button>
        </form>
      </div>

      <div className="bg-white rounded-xl p-6">
        <h2 className="text-xl font-semibold mb-4">Manage Services</h2>
        {services.map(service => (
          <div key={service.id} className="mb-4 p-4 border rounded">
            {editingService && editingService.id === service.id ? (
              <form onSubmit={handleEditService} className="space-y-2">
                <input
                  type="text"
                  value={editingService.name}
                  onChange={(e) => setEditingService({ ...editingService, name: e.target.value })}
                  className="w-full p-2 border rounded"
                />
                <input
                  type="url"
                  value={editingService.url}
                  onChange={(e) => setEditingService({ ...editingService, url: e.target.value })}
                  className="w-full p-2 border rounded"
                />
                <div className="flex justify-end space-x-2">
                  <button type="submit" className="p-2 bg-[#00A651] text-white rounded">Save</button>
                  <button onClick={() => setEditingService(null)} className="p-2 bg-gray-300 rounded">Cancel</button>
                </div>
              </form>
            ) : (
              <>
                <h3 className="font-semibold">{service.name}</h3>
                <p className="text-sm text-gray-600">{service.url}</p>
                <div className="flex justify-end space-x-2 mt-2">
                  <button onClick={() => setEditingService(service)} className="p-2 bg-[#00A651] text-white rounded">Edit</button>
                  <button onClick={() => handleDeleteService(service.id)} className="p-2 bg-red-500 text-white rounded">Delete</button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

