import QRCode from '../../components/QRCode'

export default function QRPage() {
  return <QRCode />
}

