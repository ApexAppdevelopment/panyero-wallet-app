'use client'

import { FC, useState } from 'react'
import { Send, Plus } from 'lucide-react'
import SendMoneyModal from './SendMoneyModal'
import CashInModal from './CashInModal'

interface WalletBalanceProps {
  initialBalance?: number;
}

const WalletBalance: FC<WalletBalanceProps> = ({ initialBalance }) => {
  const [balance, setBalance] = useState(initialBalance ?? 0)
  const [showSendMoney, setShowSendMoney] = useState(false)
  const [showCashIn, setShowCashIn] = useState(false)

  const handleBalanceChange = (newBalance: number) => {
    setBalance(newBalance);
  };

  return (
    <div className="gradient-bg rounded-xl shadow-md p-6 mx-4 mb-6 text-white">
      <div className="mb-4">
        <p className="text-sm opacity-80">Total balance</p>
        <h2 className="text-4xl font-bold">
          ₱{(balance ?? 0).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
        </h2>
      </div>
      
      <div className="grid grid-cols-4 gap-4">
        <button
          onClick={() => setShowCashIn(true)}
          className="flex flex-col items-center justify-center bg-white/20 rounded-2xl p-4 hover:bg-white/30 transition-colors"
        >
          <Plus className="w-6 h-6 mb-2" />
          <span className="text-xs">Cash In</span>
        </button>
        <button
          onClick={() => setShowSendMoney(true)}
          className="flex flex-col items-center justify-center bg-white/20 rounded-2xl p-4 hover:bg-white/30 transition-colors"
        >
          <Send className="w-6 h-6 mb-2" />
          <span className="text-xs">Send</span>
        </button>
      </div>

      {showSendMoney && (
        <SendMoneyModal
          onClose={() => setShowSendMoney(false)}
          balance={balance}
          onBalanceChange={handleBalanceChange}
        />
      )}
      {showCashIn && (
        <CashInModal
          onClose={() => setShowCashIn(false)}
          onBalanceChange={handleBalanceChange}
        />
      )}
    </div>
  )
}

export default WalletBalance

