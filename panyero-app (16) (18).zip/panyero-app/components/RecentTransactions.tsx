'use client'

import { FC, useEffect, useState } from 'react'
import { ArrowUp, ArrowDown } from 'lucide-react'
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore'
import { db } from '../firebase'

interface Transaction {
  id: string
  type: 'send' | 'receive'
  amount: number
  title: string
  timestamp: { seconds: number }
}

const RecentTransactions: FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([])

  useEffect(() => {
    const q = query(collection(db, 'transactions'), orderBy('timestamp', 'desc'), limit(5))
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const transactionsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Transaction))
      setTransactions(transactionsData)
    })

    return () => unsubscribe()
  }, [])

  return (
    <div className="bg-white rounded-3xl shadow-sm p-6 mb-6">
      <h3 className="font-medium text-lg mb-4">Recent Transactions</h3>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="flex items-center justify-between p-2">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                transaction.type === 'send' ? 'bg-[#FF4B55]/10' : 'bg-[#00D72F]/10'
              }`}>
                {transaction.type === 'send' ? (
                  <ArrowUp className="text-[#FF4B55]" />
                ) : (
                  <ArrowDown className="text-[#00D72F]" />
                )}
              </div>
              <div>
                <p className="font-medium">{transaction.title}</p>
                <p className="text-sm text-gray-500">
                  {transaction.timestamp && transaction.timestamp.seconds
                    ? new Date(transaction.timestamp.seconds * 1000).toLocaleDateString()
                    : 'Date not available'}
                </p>
              </div>
            </div>
            <p className={`font-medium ${
              transaction.type === 'send' ? 'transaction-negative' : 'transaction-positive'
            }`}>
              {transaction.type === 'send' ? '-' : '+'} ₱{transaction.amount.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
              })}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default RecentTransactions

