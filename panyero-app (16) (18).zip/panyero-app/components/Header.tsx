import { FC } from 'react'
import { Bell, UserCircle } from 'lucide-react'

interface HeaderProps {
  userLevel: number
}

const Header: FC<HeaderProps> = ({ userLevel }) => {
  return (
    <header className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-2">
        <h1 className="text-2xl font-bold font-roboto text-gradient-dark">Panyero</h1>
        <span className="bg-gradient-to-r from-[#00A651] to-[#00F2A9] text-white text-xs px-2 py-1 rounded-full">Lvl {userLevel}</span>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative">
          <Bell className="text-[#00A651] text-xl cursor-pointer hover:text-[#00F2A9] transition-colors" />
          <span className="absolute -top-1 -right-1 bg-red-500 w-2 h-2 rounded-full"></span>
        </div>
        <UserCircle className="text-[#00A651] text-xl cursor-pointer hover:text-[#00F2A9] transition-colors" />
      </div>
    </header>
  )
}

export default Header

