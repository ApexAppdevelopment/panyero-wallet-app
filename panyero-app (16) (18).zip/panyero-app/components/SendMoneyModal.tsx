import { useState, FC } from 'react'
import { db } from '../firebase'
import { collection, addDoc, serverTimestamp, updateDoc, doc, increment } from 'firebase/firestore'

interface SendMoneyModalProps {
  onClose: () => void
  balance: number
  onBalanceChange: (newBalance: number) => void
}

const SendMoneyModal: FC<SendMoneyModalProps> = ({ onClose, balance, onBalanceChange }) => {
  const [amount, setAmount] = useState<number | ''>('')
  const [selectedUser, setSelectedUser] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [password, setPassword] = useState('')

  const handleSendMoney = async () => {
    if (!selectedUser || amount === '' || !password) {
      setError('Please fill in all fields')
      return
    }
    if (parseFloat(amount.toString()) > balance) {
      setError('Insufficient balance')
      return
    }

    // Here you would typically verify the password with your backend
    // For this example, we'll use a dummy check
    if (password !== 'correctpassword') {
      setError('Incorrect password')
      return
    }

    try {
      const newBalance = balance - parseFloat(amount.toString())
      
      // Add transaction to Firestore
      await addDoc(collection(db, 'transactions'), {
        type: 'send',
        amount: parseFloat(amount.toString()),
        title: `Sent to ${selectedUser}`,
        timestamp: serverTimestamp(),
        recipientId: selectedUser,
      })

      // Update user's balance in Firestore
      const userRef = doc(db, 'users', 'currentUserId') // Replace 'currentUserId' with actual user ID
      await updateDoc(userRef, {
        balance: increment(-parseFloat(amount.toString()))
      })

      onBalanceChange(newBalance)
      onClose()
    } catch (error) {
      console.error('Error sending money:', error)
      setError('Failed to send money. Please try again.')
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-md hover:shadow-lg transition-shadow">
        <h3 className="font-roboto font-semibold text-[#00A651] mb-4">Send Money</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm mb-2">Select Recipient</label>
            <select
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
              value={selectedUser || ''}
              onChange={(e) => setSelectedUser(e.target.value)}
            >
              <option value="">Select a recipient</option>
              <option value="user1">User 1</option>
              <option value="user2">User 2</option>
              <option value="user3">User 3</option>
            </select>
          </div>
          <div>
            <label className="block text-sm mb-2">Amount</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
              placeholder="Enter amount"
            />
          </div>
          <div>
            <label className="block text-sm mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
              placeholder="Enter your password"
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 py-2 border border-[#00A651] text-[#00A651] rounded-lg hover:bg-[#E0F2E9] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSendMoney}
              className="flex-1 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008c44] transition-colors"
              disabled={!selectedUser || amount === '' || !password}
            >
              Send Money
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SendMoneyModal

