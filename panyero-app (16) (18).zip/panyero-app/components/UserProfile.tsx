import { FC } from 'react'
import Image from 'next/image'
import { Settings, Edit, LogOut, LayoutDashboard } from 'lucide-react'
import Link from 'next/link'

const UserProfile: FC = () => {
  return (
    <div className="bg-white rounded-xl shadow-md p-6 mb-6">
      <div className="flex items-center mb-6">
        <Image
          src="/placeholder.svg?height=100&width=100"
          alt="User Avatar"
          width={100}
          height={100}
          className="rounded-full mr-4"
        />
        <div>
          <h2 className="text-2xl font-bold text-[#1a237e]">John Doe</h2>
          <p className="text-gray-600">Seafarer</p>
        </div>
      </div>
      <div className="space-y-4">
        <ProfileItem icon={<Settings />} text="Account Settings" />
        <ProfileItem icon={<Edit />} text="Edit Profile" />
        <ProfileItem icon={<LayoutDashboard />} text="Admin Dashboard" link="/admin" />
        <ProfileItem icon={<LogOut />} text="Log Out" />
      </div>
    </div>
  )
}

const ProfileItem: FC<{ icon: React.ReactNode; text: string; link?: string }> = ({ icon, text, link }) => (
  <Link href={link || '#'} className="block">
    <div className="flex items-center p-3 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
      {icon}
      <span className="ml-3">{text}</span>
    </div>
  </Link>
)

export default UserProfile

