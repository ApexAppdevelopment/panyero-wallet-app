import { FC } from 'react'
import { Info } from 'lucide-react'

interface InfoWidgetProps {
  text: string
}

const InfoWidget: FC<InfoWidgetProps> = ({ text }) => {
  return (
    <div className="bg-white p-4 rounded-xl shadow-md hover:shadow-lg transition-shadow mb-6 border-l-4 border-[#1a237e]">
      <div className="flex items-start space-x-3">
        <div className="bg-[#1a237e] p-2 rounded-full">
          <Info className="text-white w-5 h-5" />
        </div>
        <div>
          <h3 className="font-roboto font-semibold text-[#1a237e] mb-2">Important Information</h3>
          <p className="text-gray-600">{text}</p>
        </div>
      </div>
    </div>
  )
}

export default InfoWidget

