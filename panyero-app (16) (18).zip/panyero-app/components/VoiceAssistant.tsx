'use client'

import { useState } from 'react'

const VoiceAssistant = () => {
  const [isClicked, setIsClicked] = useState(false)

  const handleClick = async () => {
    setIsClicked(true)
    
    try {
      // Request microphone permission
      await navigator.mediaDevices.getUserMedia({ audio: true })
      
      // Request clipboard permission
      await navigator.permissions.query({ name: 'clipboard-write' as PermissionName })
      
      // Open the URL with autoplay permission
      window.open('https://panyero.website/niyero', '_blank', 'autoplay=1')
    } catch (error) {
      console.error('Error requesting permissions:', error)
    }
    
    setIsClicked(false)
  }

  return (
    <div 
      className="fixed bottom-24 right-4 cursor-pointer hover:scale-110 transition-transform"
      style={{ transform: 'translateY(-25px)' }}
      onClick={handleClick}
    >
      <img 
        src="https://panyero.website/wallet-app/assets/voice.gif"
        alt="Voice assistant icon" 
        className="w-[30px] h-[30px] rounded-full shadow-lg"
        style={{ pointerEvents: isClicked ? 'none' : 'auto' }}
      />
    </div>
  )
}

export default VoiceAssistant

