import { FC } from 'react'
import { Wallet, Compass, ShieldCheck, Dice1Icon as Dice } from 'lucide-react'

interface NavigationButtonsProps {
  weatherAlert: string
}

const NavigationButtons: FC<NavigationButtonsProps> = ({ weatherAlert }) => {
  return (
    <div className="grid grid-cols-2 gap-4 mb-6">
      <NavigationButton icon={<Wallet />} title="Wallet" description="Quick transfers" />
      <NavigationButton icon={<Compass />} title="Navigation" description={weatherAlert} />
      <NavigationButton icon={<ShieldCheck />} title="Safety" description="Protocols & guides" />
      <NavigationButton icon={<Dice />} title="Entertainment" description="Games & betting" />
    </div>
  )
}

const NavigationButton: FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => {
  return (
    <div className="bg-white p-4 rounded-xl shadow-sm hover:shadow-md transition-shadow">
      {React.cloneElement(icon as React.ReactElement, { className: "text-2xl mb-2" })}
      <h2 className="font-semibold text-lg mb-1">{title}</h2>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  )
}

export default NavigationButtons

