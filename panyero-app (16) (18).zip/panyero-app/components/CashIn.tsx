'use client'

import { ArrowLeft, PiggyBank, Store, Building2, CreditCard, ChevronRight } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'

export default function CashIn() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="flex items-center p-4 gap-4">
        <Link href="/" className="p-2">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-medium">Cash in</h1>
      </div>

      {/* Promo Banner */}
      <div className="mx-4 mb-8 rounded-2xl overflow-hidden">
        <div className="bg-[#001F0E] p-6 text-white">
          <h2 className="text-xl font-medium mb-2">Mag-cash in with up to</h2>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-medium">₱30,000</span>
            <span className="text-[#00A651]">Panyero Easy Credit</span>
          </div>
        </div>
      </div>

      {/* Popular Methods */}
      <div className="px-4 mb-8">
        <h3 className="text-gray-500 font-medium mb-4">POPULAR METHODS</h3>
        <div className="bg-white rounded-2xl shadow-sm divide-y">
          <MethodItem icon={PiggyBank} text="Panyero Savings" />
          <MethodItem icon={Store} text="Panyero Center" />
          <MethodItem icon={Building2} text="Bank account" />
          <MethodItem icon={CreditCard} text="Debit or credit card" />
        </div>
      </div>

      {/* Partners */}
      <div className="px-4">
        <h3 className="text-gray-500 font-medium mb-4">OUR PARTNERS</h3>
        <div className="grid grid-cols-3 gap-4">
          {['bpi', 'bdo', 'unionbank'].map((bank) => (
            <div key={bank} className="bg-white p-4 rounded-xl shadow-sm flex items-center justify-center">
              <Image
                src={`/placeholder.svg?height=40&width=80`}
                alt={bank}
                width={80}
                height={40}
                className="h-10 w-auto"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function MethodItem({ icon: Icon, text }: { icon: any; text: string }) {
  return (
    <div className="flex items-center justify-between p-4 hover:bg-gray-50">
      <div className="flex items-center gap-4">
        <Icon className="w-6 h-6" />
        <span className="text-lg">{text}</span>
      </div>
      <ChevronRight className="w-5 h-5 text-gray-400" />
    </div>
  )
}

