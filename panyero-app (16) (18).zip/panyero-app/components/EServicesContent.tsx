'use client'

import { FC, useEffect, useState } from 'react'
import { Stethoscope, GraduationCap, Briefcase, Laptop, Palette, Film, Anchor, Shield, FlaskRoundIcon as Flask, Wrench, ChefHat, Dumbbell, Wheat, Scale, Truck, Bot, Music, Video, Image, FileText, Database, Lock, AppleIcon as Jobs, Train, Newspaper, HelpCircle, Gamepad, Trophy, FileSearch, Headphones, School, Bell, Calendar, Map, Users, Package, Fuel, PenToolIcon as Tool, Radio, FilesIcon as Docs, Umbrella, Award, Building, BanknoteIcon as Bank, ShoppingCart, Utensils, Car, Plane, Home, Gavel, PuzzleIcon as Mahjong, Dice1Icon as Dice, PuzzleIcon as Chess, Hash, PuzzleIcon as Quiz, Puzzle, Joystick, ClubIcon as Football, Ticket, Cloud, WavesIcon as Wave, AlertTriangle, Zap, Droplet, Wifi, Tv, TrendingUp, Smartphone, CreditCard, SpadeIcon as Spades, CircleDot, WalletCardsIcon as Cards, Grid, Grid3X3, Star, Clock, Gift, MapPin } from 'lucide-react'
import { useMediaQuery } from 'react-responsive'
import { collection, getDocs } from 'firebase/firestore'
import { db } from '../firebase'

const getIconForService = (serviceName: string): any => {
  // Implement logic to map service names to Lucide icons
  switch (serviceName) {
    case 'Medical': return Stethoscope;
    case 'Edu': return GraduationCap;
    case 'Business': return Briefcase;
    // Add more cases as needed...
    default: return Stethoscope; // Default icon
  }
};


const EServicesContent: FC = () => {
  const isMobile = useMediaQuery({ maxWidth: 767 })
  const [selectedService, setSelectedService] = useState<string | null>(null)
  const [services, setServices] = useState<Record<string, { icon: any; title: string; url: string }[]>>({})

  useEffect(() => {
    const fetchServices = async () => {
      const servicesCollection = collection(db, 'services')
      const serviceSnapshot = await getDocs(servicesCollection)
      const serviceList = serviceSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))

      // Group services by category
      const groupedServices = serviceList.reduce((acc, service) => {
        if (!acc[service.category]) {
          acc[service.category] = []
        }
        acc[service.category].push({
          icon: getIconForService(service.name),
          title: service.name,
          url: service.url
        })
        return acc
      }, {} as Record<string, { icon: any; title: string; url: string }[]>)

      setServices(groupedServices)
    }

    fetchServices()
  }, [])

  const handleServiceClick = (title: string) => {
    setSelectedService(title)
  }

  const handleCloseEmbed = () => {
    setSelectedService(null)
  }

  const renderCategory = (category: string, categoryServices: { icon: any; title: string; url: string }[]) => (
    <div key={category} className="mb-8">
      <div className="bg-gradient-to-r from-[#00A651] to-[#00F2A9] text-white p-4 rounded-t-xl">
        <h2 className="text-xl font-bold capitalize">{category}</h2>
      </div>
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4 p-4 bg-white rounded-b-xl shadow">
        {categoryServices.map((service, index) => (
          <div
            key={index}
            className="flex flex-col items-center justify-center p-4 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer"
            onClick={() => handleServiceClick(service.title)}
          >
            <service.icon className="w-8 h-8 text-[#00A651] mb-2" />
            <span className="text-xs font-medium text-center">{service.title}</span>
          </div>
        ))}
      </div>
    </div>
  )

  return (
    <div className="space-y-6">
      {Object.entries(services).map(([category, categoryServices]) =>
        renderCategory(category, categoryServices)
      )}
      {isMobile && selectedService && (
        <div className="fixed inset-0 z-50 bg-black">
          <div className="relative w-full h-full">
            <iframe
              src={selectedService.url}
              className="w-full h-full"
              style={{ border: 'none' }}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
            <button
              className="absolute top-4 right-4 bg-white text-black p-2 rounded-full"
              onClick={handleCloseEmbed}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default EServicesContent

